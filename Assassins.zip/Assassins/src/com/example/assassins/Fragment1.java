package com.example.assassins;

import android.app.Fragment;

public class Fragment1 extends Fragment {

}
