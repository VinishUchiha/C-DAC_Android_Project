package com.example.assassins;

import android.app.Fragment;

public class Fragment2 extends Fragment {

}
